/************Ch**************/
CONTENT OF ASSETS DIRECTORY

CSS and JS Directories Files are from espacepartenairesng4.viatelease.fr in HTDOCSSVN from old AngularJS 1.4

/***********Ch***************/
CONTENT OF ASSETS DIRECTORY

IMG Files are from ng2viatelease2 in c:\DEV\ng2viatelease2\src\assets\img>

..DATA Files are for PrimeNG objects..

/***********Ch***************/
